import asyncio
import logging
import random
from time import perf_counter

from fastapi import Depends, FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import select
from sqlalchemy.exc import SQLAlchemyError

from app.auth import AUTH_COOKIE_NAME, CSRF_COOKIE_NAME, get_current_user, require_admin_user
from app.config import get_settings
from app.db.migrations_runtime import repair_partial_installer_schema, run_runtime_migrations
from app.db.session import SessionLocal, get_db, validate_database_connection
from app.models import AppUser, Policy
from app.observability import (
    configure_logging,
    increment_metric,
    metrics_snapshot,
    new_request_id,
    set_request_id,
)
from app.resource_paths import resource_path
from app.routes.api import router as api_router
from app.routes.auth import router as auth_router
from app.routes.sync import router as sync_router
from app.security import apply_security_headers, create_csrf_token, csrf_request_allowed, csrf_token_valid
from app.seed_data import seed_main_kb_from_files
from app.services.coverage import get_coverage_rows
from app.services.prompt_store import enable_prompt_db_reads_if_rows, seed_prompts_from_files
from app.services.policy_knowledge_seed import migrate_policy_documents_from_main, seed_policy_documents_from_urls
from app.services.seed_index_bundle import install_seed_indexes
from app.services.sync_permissions import sync_client_permission_enabled
from app.services.sync_service import SyncService

settings = get_settings()

configure_logging(
    getattr(logging, settings.log_level.upper(), logging.INFO),
    structured=settings.structured_logs,
)
logger = logging.getLogger(__name__)

app = FastAPI(title=settings.app_name, debug=settings.app_debug)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory=str(resource_path("app/static"))), name="static")
templates = Jinja2Templates(directory=str(resource_path("app/templates")))

app.include_router(auth_router)
app.include_router(api_router)
app.include_router(sync_router)


@app.middleware("http")
async def log_api_request(request: Request, call_next):
    started_at = perf_counter()
    request_id = request.headers.get(settings.request_id_header) or new_request_id()
    set_request_id(request_id)
    if _sync_server_blocks_app_api(request.url.path):
        response = JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"error": True, "detail": "Endpoint is not available on this sync server."},
            headers={settings.request_id_header: request_id},
        )
        apply_security_headers(response, request, settings)
        return response
    if not await csrf_request_allowed(request, settings):
        increment_metric("csrf_rejected")
        response = JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content={"error": True, "detail": "Invalid CSRF token or request origin."},
            headers={settings.request_id_header: request_id},
        )
        apply_security_headers(response, request, settings)
        return response
    try:
        response = await call_next(request)
    except Exception:
        duration_ms = (perf_counter() - started_at) * 1000
        increment_metric("request_errors")
        logger.exception(
            "API request failed method=%s path=%s duration_ms=%.2f",
            request.method,
            request.url.path,
            duration_ms,
        )
        raise

    duration_ms = (perf_counter() - started_at) * 1000
    response.headers[settings.request_id_header] = request_id
    apply_security_headers(response, request, settings)
    increment_metric("requests_total")
    if response.status_code >= 500:
        increment_metric("responses_5xx")
    elif response.status_code >= 400:
        increment_metric("responses_4xx")
    if _should_log_access(request.url.path):
        logger.info(
            "API request method=%s path=%s status_code=%s duration_ms=%.2f",
            request.method,
            request.url.path,
            response.status_code,
            duration_ms,
        )
    if (
        settings.use_csrf_protection
        and AUTH_COOKIE_NAME in request.cookies
        and not csrf_token_valid(request.cookies.get(CSRF_COOKIE_NAME), settings)
    ):
        response.set_cookie(
            CSRF_COOKIE_NAME,
            create_csrf_token(settings),
            max_age=settings.auth_cookie_max_age_seconds,
            httponly=False,
            samesite="lax",
            secure=settings.use_secure_auth_cookie,
        )
    return response


def _should_log_access(path: str) -> bool:
    if not settings.access_log_enabled:
        return False
    if path in settings.access_log_suppressed_path_set:
        return False
    sample_rate = max(0.0, min(1.0, float(settings.access_log_sample_rate)))
    if sample_rate >= 1.0:
        return True
    if sample_rate <= 0.0:
        return False
    return random.random() < sample_rate


def _sync_server_blocks_app_api(path: str) -> bool:
    if not settings.sync_enabled:
        return False
    if str(settings.sync_mode or "").strip().casefold() != "server":
        return False
    if settings.sync_server_expose_app_apis:
        return False
    if path in {"/health", "/health/live", "/health/ready", "/metrics"}:
        return False
    return not path.startswith("/api/sync")


def _sync_server_disables_llm_services() -> bool:
    return (
        settings.sync_enabled
        and str(settings.sync_mode or "").strip().casefold() == "server"
        and not settings.sync_server_expose_app_apis
    )


def _should_seed_prompts_from_files() -> bool:
    return (
        settings.prompt_source != "file"
        and str(settings.sync_mode or "").strip().casefold() == "server"
    )


def _should_seed_policy_documents() -> bool:
    """Return whether startup may import policy documents on a client."""
    if not settings.is_client_mode:
        return True
    return bool(settings.client_startup_seed_kb_policy_documents)


@app.on_event("startup")
async def startup() -> None:
    bundle_status = install_seed_indexes(settings)
    if bundle_status != "unavailable":
        logger.info("Seed FAISS bundle: %s", bundle_status)
    validate_database_connection()
    if settings.database_auto_migrate:
        run_runtime_migrations()
    else:
        logger.info("Database auto-migration is disabled; checking installer schema health only")
        repair_partial_installer_schema()
    with SessionLocal() as db:
        migrate_policy_documents_from_main(db)
    try:
        if _should_seed_prompts_from_files():
            seeded_prompts = seed_prompts_from_files()
            if seeded_prompts:
                logger.info("Seeded %s prompt rows from packaged prompt files", seeded_prompts)
        elif enable_prompt_db_reads_if_rows():
            logger.info("Enabled database prompt reads from existing prompt rows")
    except SQLAlchemyError:
        logger.exception("Prompt database initialization failed; falling back to packaged prompt files")
    if _sync_server_disables_llm_services():
        logger.info("Sync-only server mode enabled; skipping LLM-dependent startup work")
        app.state.client_sync_task = None
        app.state.policy_knowledge_seed_task = None
        return
    app.state.policy_knowledge_seed_task = None
    app.state.policy_knowledge_seed_started = False
    if not _client_sync_configured():
        _start_policy_knowledge_seed_task()
    elif not _should_seed_policy_documents():
        logger.info("Client startup policy document seeding is disabled; Main KB seeding remains enabled")
    app.state.client_sync_task = asyncio.create_task(_client_sync_loop_after_startup())


async def _seed_policy_knowledge_after_startup() -> None:
    """Keep startup responsive while bundled and policy knowledge is indexed."""
    try:
        if _should_seed_policy_documents():
            policy_result = await seed_policy_documents_from_urls()
            logger.info("Policy knowledge startup import completed result=%s", policy_result)
        else:
            logger.info("Client startup policy document seeding is disabled")
        file_result = await seed_main_kb_from_files()
        logger.info("Bundled knowledge startup import completed result=%s", file_result)
    except Exception:
        logger.exception("Policy knowledge startup import failed")


def _start_policy_knowledge_seed_task() -> None:
    """Start the one-time policy-first knowledge import after prerequisites exist."""
    if getattr(app.state, "policy_knowledge_seed_started", False):
        return
    app.state.policy_knowledge_seed_started = True
    app.state.policy_knowledge_seed_task = asyncio.create_task(
        _seed_policy_knowledge_after_startup()
    )


async def _client_sync_loop_after_startup() -> None:
    if not _client_sync_configured():
        app.state.client_sync_task = None
        return
    if settings.sync_auto_on_startup:
        if await _run_configured_client_sync("startup"):
            _start_policy_knowledge_seed_task()
    interval = int(settings.sync_interval_seconds or 0)
    if interval <= 0:
        return
    while True:
        await asyncio.sleep(interval)
        if not _client_sync_configured():
            continue
        if await _run_configured_client_sync("interval"):
            _start_policy_knowledge_seed_task()


async def _run_configured_client_sync(trigger: str) -> bool:
    try:
        with SessionLocal() as db:
            result = await SyncService(db).exchange_with_server()
        if result.get("error"):
            logger.warning("Client sync failed trigger=%s detail=%s", trigger, result.get("detail"))
            return False
        logger.info("Client sync completed trigger=%s result=%s", trigger, result)
        return True
    except Exception:
        logger.exception("Client sync failed trigger=%s", trigger)
        return False


def _client_sync_configured() -> bool:
    return (
        settings.sync_enabled
        and str(settings.sync_mode or "").strip().casefold() == "client"
        and bool(str(settings.sync_server_url or "").strip())
        and bool(str(settings.sync_api_token or "").strip())
    )


@app.exception_handler(SQLAlchemyError)
async def database_exception_handler(_: Request, exc: SQLAlchemyError) -> JSONResponse:
    logger.exception("Database error: %s", exc)
    return JSONResponse(
        status_code=503,
        content={"error": True, "detail": "Database service is temporarily unavailable."},
    )


@app.get("/", response_class=HTMLResponse)
async def index(
    request: Request,
    current_user: AppUser | None = Depends(get_current_user),
    db = Depends(get_db),
) -> Response:
    if current_user is None:
        return RedirectResponse("/login", status_code=status.HTTP_303_SEE_OTHER)
    coverage_rows = get_coverage_rows()
    csrf_token = request.cookies.get(CSRF_COOKIE_NAME)
    if not csrf_token_valid(csrf_token, settings):
        csrf_token = create_csrf_token(settings)
    can_manage_main_knowledge = await _can_manage_main_knowledge(db, current_user)
    policy_document_options: list[dict[str, str]] = []
    if can_manage_main_knowledge:
        policy_document_options = [
            {
                "id": str(policy_id),
                "label": str(policy_title or "").strip() or "Untitled policy",
            }
            for policy_id, policy_title in db.execute(
                select(
                    Policy.id,
                    Policy.policy,
                ).order_by(
                    Policy.policy,
                    Policy.id,
                )
            ).all()
        ]
    response = templates.TemplateResponse(
        request,
        "index.html",
        {
            "app_name": settings.app_name,
            "coverage_rows": coverage_rows,
            "current_user": current_user,
            "csrf_token": csrf_token,
            "sync_enabled": bool(settings.sync_enabled),
            "can_manage_main_knowledge": can_manage_main_knowledge,
            "policy_document_options": policy_document_options,
            "can_view_prompt_library": await _can_view_prompt_library(db, current_user),
            "can_manage_prompts": await _can_manage_prompts(db, current_user),
            "can_reindex_sector_prompts": await _can_reindex_sector_prompts(db, current_user),
        },
    )
    response.set_cookie(
        CSRF_COOKIE_NAME,
        csrf_token,
        max_age=settings.auth_cookie_max_age_seconds,
        httponly=False,
        samesite="lax",
        secure=settings.use_secure_auth_cookie,
    )
    return response


async def _can_reindex_sector_prompts(db, user: AppUser) -> bool:
    if str(user.role or "").strip().casefold() != "admin":
        return False
    return await sync_client_permission_enabled(
        db,
        user,
        "can_reindex_sector_prompts",
        settings=settings,
    )


async def _can_manage_main_knowledge(db, user: AppUser) -> bool:
    if str(user.role or "").strip().casefold() != "admin":
        return False
    return await sync_client_permission_enabled(
        db,
        user,
        "can_sync_main_kb",
        settings=settings,
    )


async def _can_manage_prompts(db, user: AppUser) -> bool:
    if str(user.role or "").strip().casefold() != "admin":
        return False
    if not bool(settings.sync_enabled):
        return True
    return await sync_client_permission_enabled(
        db,
        user,
        "can_manage_prompts",
        settings=settings,
    )


async def _can_view_prompt_library(db, user: AppUser) -> bool:
    if str(user.role or "").strip().casefold() != "admin":
        return False
    return await sync_client_permission_enabled(
        db,
        user,
        "can_manage_prompts",
        settings=settings,
    )


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": settings.app_name}


@app.get("/health/live")
async def health_live() -> dict[str, str]:
    return {"status": "ok", "service": settings.app_name}


@app.get("/health/ready")
async def health_ready() -> JSONResponse:
    try:
        validate_database_connection()
    except SQLAlchemyError:
        return JSONResponse(
            status_code=503,
            content={"status": "unready", "service": settings.app_name, "database": "unavailable"},
        )
    return JSONResponse(
        content={"status": "ready", "service": settings.app_name, "database": "ok"},
    )


@app.get("/metrics")
async def metrics(current_user: AppUser = Depends(require_admin_user)) -> dict[str, object]:
    _ = current_user
    return {"metrics": metrics_snapshot()}
