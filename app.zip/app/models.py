from datetime import datetime
import uuid

from sqlalchemy import Boolean, CheckConstraint, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base


class CountrySector(Base):
    __tablename__ = "country_sectors"
    __table_args__ = (UniqueConstraint("country_id", "sector_id", name="uq_country_sector"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    country_id: Mapped[str] = mapped_column(String(36), ForeignKey("countries.id", ondelete="CASCADE"), index=True)
    sector_id: Mapped[str] = mapped_column(String(36), ForeignKey("sectors.id", ondelete="CASCADE"), index=True)


class Country(Base):
    __tablename__ = "countries"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False, index=True)
    map_code: Mapped[str | None] = mapped_column(String(8), nullable=True, index=True)
    map_path: Mapped[str | None] = mapped_column(String(255), nullable=True)

    regions: Mapped[list["Region"]] = relationship(
        back_populates="country",
        cascade="all, delete-orphan",
        lazy="selectin",
    )
    sectors: Mapped[list["Sector"]] = relationship(
        secondary="country_sectors",
        back_populates="countries",
        lazy="selectin",
    )


class Region(Base):
    __tablename__ = "regions"
    __table_args__ = (UniqueConstraint("country_id", "name", name="uq_country_region"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    country_id: Mapped[str] = mapped_column(String(36), ForeignKey("countries.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False, index=True)

    country: Mapped["Country"] = relationship(back_populates="regions")


class Sector(Base):
    __tablename__ = "sectors"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False, index=True)

    countries: Mapped[list["Country"]] = relationship(
        secondary="country_sectors",
        back_populates="sectors",
        lazy="selectin",
    )


class EvaluationQuestion(Base):
    __tablename__ = "evaluation_questions"
    __table_args__ = (UniqueConstraint("category", "sort_order", name="uq_eval_category_sort"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    category: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    chart_title: Mapped[str | None] = mapped_column(String(160), nullable=True)
    question: Mapped[str] = mapped_column(Text, nullable=False)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, index=True)

    options: Mapped[list["QuestionOption"]] = relationship(
        back_populates="question",
        cascade="all, delete-orphan",
        lazy="selectin",
    )


class QuestionOption(Base):
    __tablename__ = "question_options"
    __table_args__ = (
        UniqueConstraint("questionId", "option", name="uq_question_option"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    question_id: Mapped[str] = mapped_column(
        "questionId",
        String(36), ForeignKey("evaluation_questions.id", ondelete="CASCADE"),
        index=True,
    )
    option: Mapped[str] = mapped_column(String(255), nullable=False)

    question: Mapped["EvaluationQuestion"] = relationship(back_populates="options")


class UserSession(Base):
    __tablename__ = "user_sessions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    session_key: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    title: Mapped[str | None] = mapped_column(String(220), index=True)
    title_is_manual: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    session_data: Mapped[str | None] = mapped_column(Text)
    user_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("app_users.id", ondelete="SET NULL"), index=True
    )
    country_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("countries.id", ondelete="SET NULL"), index=True
    )
    region_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("regions.id", ondelete="SET NULL"), index=True
    )
    sector_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("sectors.id", ondelete="SET NULL"), index=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class UserChatMessage(Base):
    __tablename__ = "user_chat_messages"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    user_session_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("user_sessions.id", ondelete="CASCADE"), index=True
    )
    role: Mapped[str] = mapped_column(String(20), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    is_error: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class AppUser(Base):
    __tablename__ = "app_users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    session_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1, server_default="1")
    designation: Mapped[str] = mapped_column(String(160), nullable=False)
    organisation_type: Mapped[str] = mapped_column(String(160), nullable=False)
    organisation_name: Mapped[str] = mapped_column(String(220), nullable=False)
    role: Mapped[str] = mapped_column(String(40), nullable=False, default="user", server_default="user")
    sync_encrypted_payload: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class AppRateLimit(Base):
    __tablename__ = "app_rate_limits"

    key: Mapped[str] = mapped_column("rate_limit_key", String(255), primary_key=True)
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    window_started_at: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    locked_until: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class Prompt(Base):
    __tablename__ = "prompts"
    __table_args__ = (UniqueConstraint("prompt_key", name="uq_prompts_prompt_key"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    prompt_key: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    category: Mapped[str] = mapped_column(String(80), nullable=False, default="llm", server_default="llm", index=True)
    model: Mapped[str | None] = mapped_column(String(120), nullable=True, index=True)
    display_name: Mapped[str] = mapped_column(String(255), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    source_path: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class SystemHazard(Base):
    __tablename__ = "system_hazards"
    __table_args__ = (UniqueConstraint("sector_id", "name", name="uq_system_hazard_sector_name"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    sector_id: Mapped[str] = mapped_column(String(36), ForeignKey("sectors.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class AdditionalHazard(Base):
    __tablename__ = "additional_hazards"
    __table_args__ = (
        UniqueConstraint("country_id", "sector_id", "name", name="uq_additional_hazard_scope_name"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    country_id: Mapped[str] = mapped_column(String(36), ForeignKey("countries.id", ondelete="CASCADE"), index=True)
    sector_id: Mapped[str] = mapped_column(String(36), ForeignKey("sectors.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="csv")
    csv_row_number: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class AdditionalHazardProfile(Base):
    __tablename__ = "additional_hazard_profiles"
    __table_args__ = (
        UniqueConstraint("additional_hazard_id", "profile", name="uq_additional_hazard_profile"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    additional_hazard_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("additional_hazards.id", ondelete="CASCADE"), index=True
    )
    profile: Mapped[str] = mapped_column(String(255), nullable=False)
    evidence: Mapped[str | None] = mapped_column(Text)
    reference: Mapped[str | None] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="d4_2_pdf")
    csv_row_number: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class AdditionalHazardProfileTargetPopulation(Base):
    __tablename__ = "additional_hazard_profile_target_populations"
    __table_args__ = (
        UniqueConstraint(
            "additional_hazard_profile_id",
            "question_option_id",
            name="uq_additional_hazard_profile_target_option",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    additional_hazard_profile_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("additional_hazard_profiles.id", ondelete="CASCADE"), index=True
    )
    question_option_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("question_options.id", ondelete="CASCADE"), index=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class CustomHazard(Base):
    __tablename__ = "custom_hazards"
    __table_args__ = (
        UniqueConstraint(
            "country_id",
            "sector_id",
            "region_scope_key",
            "name_key",
            name="uq_custom_hazard_scope_name",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    country_id: Mapped[str] = mapped_column(String(36), ForeignKey("countries.id", ondelete="CASCADE"), index=True)
    sector_id: Mapped[str] = mapped_column(String(36), ForeignKey("sectors.id", ondelete="CASCADE"), index=True)
    policy_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("policies.id", ondelete="SET NULL"), index=True
    )
    region_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("regions.id", ondelete="SET NULL"), index=True)
    region_scope_key: Mapped[str] = mapped_column(String(36), nullable=False, default="", server_default="")
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    name_key: Mapped[str] = mapped_column(String(255), nullable=False)
    reason: Mapped[str | None] = mapped_column(Text)
    evidence: Mapped[str | None] = mapped_column(Text)
    summary: Mapped[str | None] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="user", server_default="user")
    validation_mode: Mapped[str] = mapped_column(String(16), nullable=False, default="strict", server_default="strict")
    is_crowd_sourced: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="0")
    created_by_user_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("app_users.id", ondelete="SET NULL"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class CustomHazardProfile(Base):
    __tablename__ = "custom_hazard_profiles"
    __table_args__ = (
        UniqueConstraint("custom_hazard_id", "profile_key", name="uq_custom_hazard_profile"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    custom_hazard_id: Mapped[str] = mapped_column(String(36), ForeignKey("custom_hazards.id", ondelete="CASCADE"), index=True)
    profile: Mapped[str] = mapped_column(Text, nullable=False)
    profile_key: Mapped[str] = mapped_column(String(255), nullable=False)
    variable_name: Mapped[str | None] = mapped_column(String(160))
    explanation: Mapped[str | None] = mapped_column(Text)
    statistical_basis: Mapped[str | None] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="custom_hazard_extraction")
    metadata_json: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class UserHazard(Base):
    __tablename__ = "user_hazards"
    __table_args__ = (UniqueConstraint("user_session_id", "name", name="uq_user_session_hazard"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    user_session_id: Mapped[str] = mapped_column(String(36), ForeignKey("user_sessions.id", ondelete="CASCADE"), index=True)
    custom_hazard_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("custom_hazards.id", ondelete="SET NULL"), index=True)
    system_hazard_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("system_hazards.id", ondelete="SET NULL"), index=True)
    sector_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("sectors.id", ondelete="SET NULL"), index=True)
    region_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("regions.id", ondelete="SET NULL"), index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="custom")
    validation_mode: Mapped[str] = mapped_column(String(16), nullable=False, default="strict", server_default="strict")
    is_crowd_sourced: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="0")
    reason: Mapped[str | None] = mapped_column(Text)
    evidence: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class UserHazardSocioDemographic(Base):
    __tablename__ = "user_hazard_socio_demographics"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    user_session_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("user_sessions.id", ondelete="CASCADE"), index=True
    )
    user_hazard_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("user_hazards.id", ondelete="CASCADE"), index=True)
    custom_hazard_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("custom_hazards.id", ondelete="CASCADE"), index=True)
    system_hazard_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("system_hazards.id", ondelete="CASCADE"), index=True
    )
    additional_hazard_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("additional_hazards.id", ondelete="CASCADE"), index=True
    )
    country_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("countries.id", ondelete="SET NULL"), index=True)
    region_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("regions.id", ondelete="SET NULL"), index=True)
    sector_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("sectors.id", ondelete="SET NULL"), index=True)
    variable_name: Mapped[str | None] = mapped_column(String(160))
    profile: Mapped[str] = mapped_column(Text, nullable=False)
    explanation: Mapped[str | None] = mapped_column(Text)
    statistical_basis: Mapped[str | None] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="llm")
    metadata_json: Mapped[str | None] = mapped_column(Text)
    reason: Mapped[str | None] = mapped_column(Text)
    evidence: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class SystemHazardSocioDemographic(Base):
    __tablename__ = "system_hazard_socio_demographics"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    system_hazard_id: Mapped[str] = mapped_column(String(36), ForeignKey("system_hazards.id", ondelete="CASCADE"), index=True)
    sector_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("sectors.id", ondelete="SET NULL"), index=True)
    variable_name: Mapped[str | None] = mapped_column(String(160))
    variable_type: Mapped[str] = mapped_column(
        String(40), nullable=False, default="individual", server_default="individual"
    )
    profile: Mapped[str] = mapped_column(Text, nullable=False)
    explanation: Mapped[str | None] = mapped_column(Text)
    statistical_basis: Mapped[str | None] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="sector_prompt")
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class SystemHazardSocioDemographicTargetPopulation(Base):
    __tablename__ = "system_hazard_socio_demographic_target_populations"
    __table_args__ = (
        UniqueConstraint(
            "system_hazard_socio_demographic_id",
            "question_option_id",
            name="uq_system_dg_target_population_option",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    system_hazard_socio_demographic_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("system_hazard_socio_demographics.id", ondelete="CASCADE"), index=True
    )
    question_option_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("question_options.id", ondelete="CASCADE"), index=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class UserMitigationMeasure(Base):
    __tablename__ = "user_mitigation_measures"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    user_session_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("user_sessions.id", ondelete="CASCADE"), index=True
    )
    user_hazard_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("user_hazards.id", ondelete="CASCADE"), index=True)
    custom_hazard_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("custom_hazards.id", ondelete="CASCADE"), index=True)
    system_hazard_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("system_hazards.id", ondelete="CASCADE"), index=True
    )
    additional_hazard_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("additional_hazards.id", ondelete="CASCADE"), index=True
    )
    measure: Mapped[str] = mapped_column(Text, nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    target_population: Mapped[str | None] = mapped_column(Text)
    conclusion: Mapped[str | None] = mapped_column(Text)
    target_groups_json: Mapped[str | None] = mapped_column(Text)
    creation_details_json: Mapped[str | None] = mapped_column(Text)
    system_inquiry_json: Mapped[str | None] = mapped_column(Text)
    validation_mode: Mapped[str] = mapped_column(String(16), nullable=False, default="strict", server_default="strict")
    is_crowd_sourced: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="0")
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class SystemInquiryTelemetryEvent(Base):
    __tablename__ = "system_inquiry_telemetry_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    event_key: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    payload_json: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="queued", server_default="queued", index=True)
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    last_error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)
    synced_at: Mapped[datetime | None] = mapped_column(DateTime)


class MitigationMeasureExample(Base):
    __tablename__ = "mitigation_measure_examples"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    sector_id: Mapped[str] = mapped_column(String(36), ForeignKey("sectors.id", ondelete="CASCADE"), index=True)
    system_hazard_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("system_hazards.id", ondelete="SET NULL"), index=True
    )
    system_hazard_socio_demographic_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("system_hazard_socio_demographics.id", ondelete="SET NULL"), index=True
    )
    profile_label: Mapped[str | None] = mapped_column(String(255))
    measure: Mapped[str] = mapped_column(Text, nullable=False)
    policy_case_study: Mapped[str | None] = mapped_column(Text)
    country_city: Mapped[str | None] = mapped_column(String(255))
    implementation_summary: Mapped[str | None] = mapped_column(Text)
    evidence: Mapped[str | None] = mapped_column(Text)
    reference_links: Mapped[str | None] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="seed", server_default="seed")
    csv_row_number: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class Policy(Base):
    __tablename__ = "policies"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    country_id: Mapped[str] = mapped_column(String(36), ForeignKey("countries.id", ondelete="CASCADE"), index=True)
    sector_id: Mapped[str] = mapped_column(String(36), ForeignKey("sectors.id", ondelete="CASCADE"), index=True)
    policy: Mapped[str] = mapped_column(Text, nullable=False)
    policy_url: Mapped[str | None] = mapped_column(Text)
    language: Mapped[str | None] = mapped_column(String(120))
    policy_type: Mapped[str | None] = mapped_column(String(120))
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="xlsx", server_default="xlsx")
    created_by_user_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("app_users.id", ondelete="SET NULL"), index=True
    )
    is_crowd_sourced: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="0")
    excel_row_number: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class PolicyHazardLink(Base):
    __tablename__ = "policy_hazard_links"
    __table_args__ = (
        UniqueConstraint("policy_id", "system_hazard_id", name="uq_policy_system_hazard"),
        UniqueConstraint("policy_id", "additional_hazard_id", name="uq_policy_additional_hazard"),
        CheckConstraint("(system_hazard_id IS NULL) <> (additional_hazard_id IS NULL)", name="chk_policy_hazard_target"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    policy_id: Mapped[str] = mapped_column(String(36), ForeignKey("policies.id", ondelete="CASCADE"), index=True)
    system_hazard_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("system_hazards.id", ondelete="CASCADE"), index=True)
    additional_hazard_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("additional_hazards.id", ondelete="CASCADE"), index=True)
    rationale: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class MitigationMeasurePolicy(Base):
    __tablename__ = "mitigation_measure_policies"
    __table_args__ = (
        UniqueConstraint(
            "policy_code",
            "sector_id",
            "source",
            name="uq_mitigation_policy_code_sector_source",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    policy_code: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    policy_title: Mapped[str] = mapped_column(Text, nullable=False)
    country_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("countries.id", ondelete="SET NULL"), nullable=True, index=True
    )
    sector_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("sectors.id", ondelete="SET NULL"), nullable=True, index=True
    )
    policy_type: Mapped[str | None] = mapped_column(String(120))
    short_description: Mapped[str | None] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="xlsx", server_default="xlsx")
    excel_row_number: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class MitigationMeasureTargetGroup(Base):
    __tablename__ = "mitigation_measure_target_groups"
    __table_args__ = (
        UniqueConstraint(
            "mitigation_measure_policy_id",
            "question_option_id",
            name="uq_mitigation_target_group_xlsx_cell",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    mitigation_measure_policy_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("mitigation_measure_policies.id", ondelete="CASCADE"), index=True
    )
    question_option_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("question_options.id", ondelete="CASCADE"), index=True
    )
    match_value: Mapped[str | None] = mapped_column(String(40), index=True)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="xlsx", server_default="xlsx")
    excel_column_number: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class MitigationMeasurePolicyAdditionalHazard(Base):
    __tablename__ = "mitigation_measure_policy_additional_hazards"
    __table_args__ = (
        UniqueConstraint(
            "mitigation_measure_policy_id",
            "additional_hazard_id",
            name="uq_mitigation_policy_additional_hazard",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    mitigation_measure_policy_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("mitigation_measure_policies.id", ondelete="CASCADE"), index=True
    )
    additional_hazard_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("additional_hazards.id", ondelete="CASCADE"), index=True
    )
    match_value: Mapped[str | None] = mapped_column(String(40), index=True)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="xlsx", server_default="xlsx")
    excel_row_number: Mapped[int | None] = mapped_column(Integer)
    excel_column_number: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class MitigationMeasurePolicySystemHazard(Base):
    __tablename__ = "mitigation_measure_policy_system_hazards"
    __table_args__ = (
        UniqueConstraint(
            "mitigation_measure_policy_id",
            "system_hazard_id",
            name="uq_mitigation_policy_system_hazard",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    mitigation_measure_policy_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("mitigation_measure_policies.id", ondelete="CASCADE"), index=True
    )
    system_hazard_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("system_hazards.id", ondelete="CASCADE"), index=True
    )
    mitigation_effect: Mapped[str | None] = mapped_column(String(40), index=True)
    source: Mapped[str] = mapped_column(String(40), nullable=False, default="xlsx", server_default="xlsx")
    excel_row_number: Mapped[int | None] = mapped_column(Integer)
    excel_column_number: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class UserQuestionResponse(Base):
    __tablename__ = "user_question_responses"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    user_session_id: Mapped[str] = mapped_column(String(36), ForeignKey("user_sessions.id", ondelete="CASCADE"), index=True)
    user_hazard_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("user_hazards.id", ondelete="SET NULL"), index=True)
    custom_hazard_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("custom_hazards.id", ondelete="SET NULL"), index=True)
    system_hazard_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("system_hazards.id", ondelete="SET NULL"), index=True
    )
    additional_hazard_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("additional_hazards.id", ondelete="SET NULL"), index=True
    )
    mitigation_measure_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("user_mitigation_measures.id", ondelete="SET NULL"),
        index=True,
    )
    question_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("evaluation_questions.id", ondelete="SET NULL"), index=True)
    question_option_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("question_options.id", ondelete="SET NULL"), index=True)
    category: Mapped[str | None] = mapped_column(String(120), index=True)
    response_text: Mapped[str | None] = mapped_column(Text)
    score: Mapped[int | None] = mapped_column(Integer)
    reason: Mapped[str | None] = mapped_column(Text)
    evidence: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class KnowledgeDocument(Base):
    __tablename__ = "knowledge_documents"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    user_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("app_users.id", ondelete="CASCADE"), index=True
    )
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    source_type: Mapped[str] = mapped_column(String(40), nullable=False)
    source_uri: Mapped[str | None] = mapped_column(Text)
    scope: Mapped[str] = mapped_column(String(20), nullable=False, default="main", index=True)
    faiss_indexed: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    session_key: Mapped[str | None] = mapped_column(String(64), index=True)
    custom_hazard_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("custom_hazards.id", ondelete="SET NULL"), index=True
    )
    policy_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("policies.id", ondelete="SET NULL"), index=True
    )
    scope_level: Mapped[str] = mapped_column(String(20), nullable=False, default="global", server_default="global", index=True)
    country_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("countries.id", ondelete="SET NULL"), index=True)
    region_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("regions.id", ondelete="SET NULL"), index=True)
    sector_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("sectors.id", ondelete="SET NULL"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class CustomHazardPolicyReference(Base):
    __tablename__ = "custom_hazard_policy_references"

    custom_hazard_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("custom_hazards.id", ondelete="CASCADE"),
        primary_key=True,
    )
    knowledge_document_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("knowledge_documents.id", ondelete="CASCADE"),
        primary_key=True,
        index=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )


class KnowledgeChunk(Base):
    __tablename__ = "knowledge_chunks"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    document_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("knowledge_documents.id", ondelete="CASCADE"), index=True
    )
    user_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("app_users.id", ondelete="CASCADE"), index=True
    )
    chunk_index: Mapped[int] = mapped_column(Integer, nullable=False)
    faiss_indexed: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    content: Mapped[str] = mapped_column(Text, nullable=False)
    source_type: Mapped[str] = mapped_column(String(40), nullable=False)
    source_uri: Mapped[str | None] = mapped_column(Text)
    page_number: Mapped[int | None] = mapped_column(Integer)
    scope_level: Mapped[str] = mapped_column(String(20), nullable=False, default="global", server_default="global", index=True)
    country_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("countries.id", ondelete="SET NULL"), index=True)
    region_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("regions.id", ondelete="SET NULL"), index=True)
    sector_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("sectors.id", ondelete="SET NULL"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class EurostatPopulationCache(Base):
    __tablename__ = "eurostat_population_cache"
    __table_args__ = (
        UniqueConstraint(
            "country_id",
            "region_id",
            "sector_id",
            "system_hazard_id",
            "profile",
            name="uq_eurostat_population_lookup",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    country: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    region: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    country_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("countries.id", ondelete="CASCADE"), nullable=True, index=True
    )
    region_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("regions.id", ondelete="CASCADE"), nullable=True, index=True
    )
    sector_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("sectors.id", ondelete="CASCADE"), nullable=True, index=True
    )
    system_hazard_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("system_hazards.id", ondelete="CASCADE"), nullable=True, index=True
    )
    profile: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    response_json: Mapped[str] = mapped_column(Text, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class SystemHazardSocioDemographicPopulationMatch(Base):
    __tablename__ = "system_hazard_socio_demographic_population_matches"
    __table_args__ = (
        UniqueConstraint(
            "system_hazard_socio_demographic_id",
            "eurostat_population_cache_id",
            name="uq_system_dg_eurostat_cache_match",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    system_hazard_socio_demographic_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("system_hazard_socio_demographics.id", ondelete="CASCADE"),
        index=True,
    )
    eurostat_population_cache_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("eurostat_population_cache.id", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )
    match_status: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    attempt_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class HazardListingCache(Base):
    __tablename__ = "hazard_listing_cache"
    __table_args__ = (
        UniqueConstraint(
            "country_id",
            "region_scope_key",
            "sector_id",
            "cache_version",
            name="uq_hazard_listing_context_version",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    country_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("countries.id", ondelete="CASCADE"), index=True
    )
    region_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("regions.id", ondelete="CASCADE"), nullable=True, index=True
    )
    region_scope_key: Mapped[str] = mapped_column(String(36), nullable=False, default="", server_default="", index=True)
    sector_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("sectors.id", ondelete="CASCADE"), index=True
    )
    cache_version: Mapped[str] = mapped_column(String(40), nullable=False, default="v1")
    source_fingerprint: Mapped[str] = mapped_column(String(64), nullable=False)
    payload_json: Mapped[str] = mapped_column(Text, nullable=False)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class UserActivity(Base):
    __tablename__ = "user_activities"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    user_session_id: Mapped[str] = mapped_column(String(36), ForeignKey("user_sessions.id", ondelete="CASCADE"), index=True)
    activity_type: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    step: Mapped[str | None] = mapped_column(String(120))
    details: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    user_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("app_users.id", ondelete="SET NULL"), index=True)
    action: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(40), nullable=False, default="success", server_default="success")
    target_type: Mapped[str | None] = mapped_column(String(80), index=True)
    target_id: Mapped[str | None] = mapped_column(String(160), index=True)
    request_id: Mapped[str | None] = mapped_column(String(64), index=True)
    ip_address: Mapped[str | None] = mapped_column(String(80))
    user_agent: Mapped[str | None] = mapped_column(String(255))
    details: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class LlmExchangeLog(Base):
    __tablename__ = "llm_exchange_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    request_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    provider: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    endpoint: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    model: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    status_code: Mapped[int | None] = mapped_column(Integer)
    duration_ms: Mapped[float | None] = mapped_column(Float)
    request_payload: Mapped[str] = mapped_column(Text, nullable=False)
    response_payload: Mapped[str | None] = mapped_column(Text)
    error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)
